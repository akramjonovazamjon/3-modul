package uz.b25.task_online_platform.task1;

public class NotextException extends Exception{
    public NotextException() {
        super("Kiritilgan matn bo’sh bo’lmasligi kerak");
    }
}
